-- MySQL dump 10.14  Distrib 5.5.52-MariaDB, for Linux (x86_64)
--
-- Host: www_valueq_mysql_m01    Database: pingou
-- ------------------------------------------------------
-- Server version	5.6.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_info`
--

DROP TABLE IF EXISTS `api_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_info` (
  `api_id` int(11) NOT NULL,
  `is_del` int(11) DEFAULT '0',
  `appKey` varchar(200) DEFAULT NULL,
  `appSecret` varchar(200) DEFAULT NULL,
  `merchant_id` int(11) NOT NULL DEFAULT '0',
  `appName` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='第三方接口信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_info`
--

LOCK TABLES `api_info` WRITE;
/*!40000 ALTER TABLE `api_info` DISABLE KEYS */;
INSERT INTO `api_info` VALUES (0,0,'pp_vq_gb','123456',19,'groupBuy');
/*!40000 ALTER TABLE `api_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_token`
--

DROP TABLE IF EXISTS `api_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_token` (
  `api_id` int(11) NOT NULL AUTO_INCREMENT,
  `access_token` varchar(250) NOT NULL,
  `is_del` int(11) DEFAULT '0',
  `api_name` varchar(100) NOT NULL,
  `merchant_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`api_id`),
  UNIQUE KEY `api_token_api_name_uindex` (`api_name`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COMMENT='第三方接口token';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_token`
--

LOCK TABLES `api_token` WRITE;
/*!40000 ALTER TABLE `api_token` DISABLE KEYS */;
INSERT INTO `api_token` VALUES (1,'eyJBbGciOiJIUzI1NiIsIlR5cGUiOiJqd3QifQ==.eyJVc2VyX2lkIjoiMTMiLCJVc2VyX25hbWUiOiJwcF92cV9nYiIsIlRva2VuX2V4cGlyZSI6IjE1NDE5MjAzMDUifQ==.3ec0573d72ff8f4a25a3485574200c04193094eb269ad889e59d2c0dab312909',0,'groupBuy',19);
/*!40000 ALTER TABLE `api_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `area_id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL,
  `is_on` varchar(4) NOT NULL DEFAULT 'off',
  `is_shown_index` varchar(4) NOT NULL DEFAULT 'off',
  `is_del` tinyint(1) DEFAULT '0',
  `area_name` varchar(255) DEFAULT NULL,
  `banner` text,
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='商品分区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attrset`
--

DROP TABLE IF EXISTS `attrset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attrset` (
  `attr_set_id` int(11) NOT NULL AUTO_INCREMENT,
  `sku_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0：普通文本属性 1：普通列表属性 2：sku列表属性 3sku颜色属性',
  `is_del` tinyint(4) DEFAULT '0',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `merchant_id` int(11) NOT NULL DEFAULT '0',
  `attr_alias` varchar(300) DEFAULT NULL COMMENT '多语言情况下的不同语言别名 {language_id:alias_name}',
  PRIMARY KEY (`attr_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COMMENT='属性表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attrset`
--

LOCK TABLES `attrset` WRITE;
/*!40000 ALTER TABLE `attrset` DISABLE KEYS */;
INSERT INTO `attrset` VALUES (43,0,0,0,'2018-10-30 08:13:01','2018-10-30 08:13:33',19,'{\"50\":\"women shoes\"}');
/*!40000 ALTER TABLE `attrset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_img`
--

DROP TABLE IF EXISTS `comment_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment_img` (
  `comment_img_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_comments_id` int(11) NOT NULL COMMENT '评论表中的id',
  `goods_id` int(11) DEFAULT NULL,
  `img_src` varchar(60) DEFAULT NULL COMMENT '图片地址',
  `img_name` varchar(60) DEFAULT NULL COMMENT '图片名字',
  `is_append` int(11) DEFAULT '0' COMMENT '是否是追加图片',
  `is_del` int(11) DEFAULT '0',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_img`
--

LOCK TABLES `comment_img` WRITE;
/*!40000 ALTER TABLE `comment_img` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_img` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(30) NOT NULL,
  `country_abbre` varchar(10) DEFAULT NULL COMMENT '国家名字缩写',
  `continent` varchar(20) DEFAULT NULL COMMENT '所在洲',
  `currency_id` int(11) DEFAULT '0' COMMENT '结算货币',
  `is_on` varchar(5) DEFAULT 'on' COMMENT '是否启用',
  `flag` varchar(100) DEFAULT NULL COMMENT '国旗图标',
  `is_del` tinyint(4) DEFAULT '0',
  `zone_num` int(11) DEFAULT NULL COMMENT '国际区号',
  `show_province` varchar(5) DEFAULT 'off' COMMENT '开启省份',
  `merchant_id` int(11) DEFAULT '0' COMMENT '租户id',
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `currency_id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_flag` varchar(50) DEFAULT NULL COMMENT '货币国旗',
  `currency_name` varchar(255) DEFAULT NULL,
  `is_on` varchar(5) NOT NULL DEFAULT 'on',
  `is_site_default` varchar(5) DEFAULT 'off',
  `is_admin_default` varchar(5) DEFAULT 'off',
  `is_del` tinyint(4) DEFAULT '0',
  `currency_img` varchar(60) DEFAULT NULL,
  `dollar_exchange_rate` decimal(10,4) DEFAULT '0.0000' COMMENT '美元汇率',
  `merchant_id` int(11) DEFAULT '0',
  `country_code` varchar(4) DEFAULT NULL,
  `currency_code` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`currency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COMMENT='货币';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (32,'$','{\"50\":\"\"}','on','off','off',0,NULL,1.0000,19,'US','USD'),(33,'¥',NULL,'on','off','off',0,NULL,6.8000,19,'CN','CNY'),(34,'Rp',NULL,'on','off','off',0,NULL,14830.0000,19,'ID','IDR'),(35,'Rbs',NULL,'on','off','off',0,NULL,68.0000,19,'RU','RUB'),(36,'¥',NULL,'on','off','off',0,NULL,112.0000,19,'JP','JPY');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distribution_sale_set`
--

DROP TABLE IF EXISTS `distribution_sale_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `distribution_sale_set` (
  `set_id` int(11) NOT NULL AUTO_INCREMENT,
  `set_level` varchar(30) NOT NULL,
  `set_val` varchar(50) NOT NULL,
  `is_del` int(11) DEFAULT '0',
  `is_open` tinyint(4) NOT NULL DEFAULT '0',
  `merchant_id` int(11) NOT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='分销参数设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distribution_sale_set`
--

LOCK TABLES `distribution_sale_set` WRITE;
/*!40000 ALTER TABLE `distribution_sale_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `distribution_sale_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facebook`
--

DROP TABLE IF EXISTS `facebook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facebook` (
  `iId` int(11) NOT NULL AUTO_INCREMENT,
  `facename` char(50) NOT NULL,
  `facepwd` char(50) NOT NULL,
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_del` int(11) DEFAULT '0' COMMENT '0表示存在,1表示删除',
  `merchant_id` int(11) DEFAULT '0',
  PRIMARY KEY (`iId`),
  UNIQUE KEY `facename` (`facename`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facebook`
--

LOCK TABLES `facebook` WRITE;
/*!40000 ALTER TABLE `facebook` DISABLE KEYS */;
/*!40000 ALTER TABLE `facebook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fodder`
--

DROP TABLE IF EXISTS `fodder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fodder` (
  `fodder_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(30) DEFAULT NULL,
  `file_type` varchar(10) DEFAULT NULL,
  `is_del` tinyint(1) DEFAULT '0',
  `fodder_video` varchar(50) DEFAULT NULL,
  `fodder_imgs` varchar(255) DEFAULT NULL,
  `fodder_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `merchant_id` int(11) NOT NULL,
  `like_num` int(10) DEFAULT '0',
  `share_num` int(10) DEFAULT '0',
  `download_num` int(10) DEFAULT '0',
  `user_via` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`fodder_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COMMENT='商品素材表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fodder`
--

LOCK TABLES `fodder` WRITE;
/*!40000 ALTER TABLE `fodder` DISABLE KEYS */;
/*!40000 ALTER TABLE `fodder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `freight_template`
--

DROP TABLE IF EXISTS `freight_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `freight_template` (
  `freight_template_id` int(11) NOT NULL AUTO_INCREMENT,
  `freight_template_name` varchar(30) DEFAULT NULL,
  `is_free` tinyint(4) DEFAULT '0' COMMENT '是否包邮',
  `cost_way_id` tinyint(4) DEFAULT '1',
  `default_first_num` decimal(10,2) DEFAULT '0.00' COMMENT '默认首重（件）',
  `default_plus_num` decimal(10,2) DEFAULT '0.00' COMMENT '默认续重',
  `default_first_freight` decimal(10,2) DEFAULT '0.00' COMMENT '默认首费',
  `default_plus_freight` decimal(10,2) DEFAULT '0.00' COMMENT '默认续费',
  `is_del` tinyint(4) DEFAULT '0',
  `shipping_from` varchar(40) DEFAULT NULL COMMENT '发货地址',
  `merchant_id` int(11) DEFAULT '0',
  PRIMARY KEY (`freight_template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `freight_template`
--

LOCK TABLES `freight_template` WRITE;
/*!40000 ALTER TABLE `freight_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `freight_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `freight_template_items`
--

DROP TABLE IF EXISTS `freight_template_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `freight_template_items` (
  `freight_template_items_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_num` decimal(10,2) DEFAULT '0.00' COMMENT '首重',
  `first_freight` decimal(10,2) DEFAULT '0.00' COMMENT '首费',
  `plus_num` decimal(10,2) DEFAULT '0.00' COMMENT '续重',
  `plus_freight` decimal(10,2) DEFAULT '0.00' COMMENT '续费',
  `is_del` tinyint(4) DEFAULT '0',
  `cost_way_id` tinyint(4) DEFAULT '1',
  `shipping_from` varchar(40) DEFAULT NULL COMMENT '发货地址',
  `merchant_id` int(11) DEFAULT '0',
  PRIMARY KEY (`freight_template_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='运费模板明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `freight_template_items`
--

LOCK TABLES `freight_template_items` WRITE;
/*!40000 ALTER TABLE `freight_template_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `freight_template_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods`
--

DROP TABLE IF EXISTS `goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods` (
  `goods_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_name` varchar(30) DEFAULT NULL,
  `sku_no` varchar(50) DEFAULT '' COMMENT '出厂编码',
  `category_id` varchar(30) DEFAULT NULL COMMENT '分类id',
  `goods_custom_url` varchar(40) DEFAULT NULL COMMENT '自定义url',
  `is_del` tinyint(4) DEFAULT '0',
  `created_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_free_shipping` varchar(10) DEFAULT 'off' COMMENT '免运费',
  `goods_weight` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '重量',
  `goods_len` decimal(10,2) DEFAULT '0.00' COMMENT '长度',
  `goods_height` decimal(10,2) DEFAULT '0.00' COMMENT '高',
  `goods_width` decimal(10,2) DEFAULT '0.00' COMMENT '宽',
  `is_volume_weight` varchar(10) DEFAULT 'off' COMMENT '是否是体积重',
  `goods_sale_num` decimal(10,2) DEFAULT '0.00' COMMENT '产品销售量',
  `goods_stock_num` decimal(10,2) DEFAULT '0.00' COMMENT '库存',
  `goods_warn_stock_num` decimal(10,2) DEFAULT '0.00' COMMENT '警告库存',
  `is_on_shelf` varchar(10) DEFAULT '1',
  `merchant_id` int(11) DEFAULT '0' COMMENT 'saas 用户id',
  `goods_price` decimal(10,2) DEFAULT '0.00',
  `goods_origin_price` decimal(10,2) DEFAULT '0.00',
  `goods_main_img` varchar(150) DEFAULT NULL,
  `goods_weight_unit` varchar(10) DEFAULT NULL COMMENT '重量单位\n\n',
  `shop_id` int(11) DEFAULT '0',
  `goods_no` varchar(50) DEFAULT NULL,
  `goods_alias` varchar(700) NOT NULL,
  `goods_short_detail` text,
  `goods_detail` longtext,
  `shop_price` decimal(10,2) DEFAULT '0.00',
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `goods_attr_val_ids` varchar(256) DEFAULT NULL COMMENT 'sku 选项id集合',
  `sku_is_combination` tinyint(4) DEFAULT '0',
  `temp_id` int(11) NOT NULL DEFAULT '1',
  `is_hot` tinyint(4) DEFAULT '0',
  `is_new` tinyint(4) DEFAULT '0',
  `is_index` tinyint(4) DEFAULT '1',
  `goods_moq` int(11) DEFAULT '0',
  `goods_most_buy_num` int(11) DEFAULT '0',
  `is_open_default_review` tinyint(4) DEFAULT '0',
  `is_fixed_time_on` tinyint(4) DEFAULT '0',
  `fixed_time` varchar(60) DEFAULT NULL,
  `default_review_point` decimal(10,2) DEFAULT '0.00',
  `default_review_num` decimal(10,0) DEFAULT '0',
  `favorite_num` decimal(10,0) DEFAULT '0',
  `order_level` int(11) DEFAULT NULL,
  `stock_out_show` varchar(30) DEFAULT NULL COMMENT '缺货显示内容',
  `sort_level` int(11) DEFAULT '0' COMMENT '排序等级',
  `goods_video` varchar(50) DEFAULT NULL,
  `goods_cover_img` varchar(50) DEFAULT NULL,
  `goods_description_img` varchar(280) DEFAULT NULL,
  `goods_short_name` varchar(8) DEFAULT NULL,
  `notice` text,
  PRIMARY KEY (`goods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=273 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods`
--

LOCK TABLES `goods` WRITE;
/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` VALUES (271,'Converse','118449','95',NULL,0,NULL,'2018-10-30 08:18:29','off',0.00,0.00,0.00,0.00,'off',568.00,45.00,21.00,'1',19,51.20,0.00,'static/goodsNews/154097498511844949854478-Snipaste_2018-09-29_18-21-23.png',NULL,0,'49854478','{\"50\":\"Converse Chuck Taylor All Star High Top\"}','{\"50\":\"100% Textile\\r\\nImported\\r\\nRubber sole\\r\\nShaft measures approximately high-top from arch\\r\\nLace-up, high-top sneaker\\r\\nOrthoLite insole for cushioning\\r\\nMedial eyelets for airflow\\r\\nCanvas upper\"}','{\"50\":\"\\u003cdiv id=\\\"dp_productDescription_container_div\\\" class=\\\"celwidget flavor-3391\\\" data-feature-name=\\\"productDescription\\\" data-cel-widget=\\\"dp_productDescription_container_div\\\" style=\\\"box-sizing: border-box; color: rgb(17, 17, 17); font-family: \\u0026quot;Amazon Ember\\u0026quot;, Arial, sans-serif; font-size: 13px; background-color: rgb(255, 255, 255);\\\"\\u003e\\u003cdiv id=\\\"productDescription_feature_div\\\" data-feature-name=\\\"productDescription\\\" data-template-name=\\\"productDescription\\\" class=\\\"a-row feature\\\" data-cel-widget=\\\"productDescription_feature_div\\\" style=\\\"box-sizing: border-box; width: 1867px;\\\"\\u003e\\u003ch2 class=\\\"softlines\\\" style=\\\"box-sizing: border-box; padding: 0px 0px 4px; margin: 0px; text-rendering: optimizeLegibility; line-height: 1.3; font-size: 21px !important; color: rgb(51, 51, 51) !important;\\\"\\u003eProduct description\\u003c/h2\\u003e\\u003cdiv id=\\\"productDescription\\\" class=\\\"a-section a-spacing-small\\\" style=\\\"box-sizing: border-box; margin: 0.5em 0px 0em 25px; color: rgb(51, 51, 51); word-wrap: break-word; font-size: small; line-height: initial;\\\"\\u003e\\u003cp style=\\\"box-sizing: border-box; padding: 0px; margin: 0em 0px 1em 1em;\\\"\\u003eThe iconic, timeless chuck taylor all star sneaker. Perfect in its simplicity since 1917. Lightweight, breathable canvas construction. Vulcanized rubber sole delivers durable traction. An ortholite insole cushions each and every step. AND no one can ignore the unmistakable ankle patch. Versatile, fashionable, and they keep looking better every time you wear them. Ortholite is a trademark of O2 partners, llc.\\u003c/p\\u003e\\u003c/div\\u003e\\u003c/div\\u003e\\u003c/div\\u003e\\u003cdiv id=\\\"detailBullets\\\" class=\\\"celwidget\\\" data-feature-name=\\\"detailBullets\\\" data-cel-widget=\\\"detailBullets\\\" style=\\\"box-sizing: border-box; color: rgb(17, 17, 17); font-family: \\u0026quot;Amazon Ember\\u0026quot;, Arial, sans-serif; font-size: 13px; background-color: rgb(255, 255, 255);\\\"\\u003e\\u003cdiv id=\\\"detailBulletsWrapper_feature_div\\\" data-feature-name=\\\"detailBullets\\\" data-template-name=\\\"detailBullets\\\" class=\\\"a-section a-spacing-none feature\\\" data-cel-widget=\\\"detailBulletsWrapper_feature_div\\\" style=\\\"box-sizing: border-box; margin-bottom: 0px;\\\"\\u003e\\u003cdiv id=\\\"detailBullets_feature_div\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003cul class=\\\"a-unordered-list a-nostyle a-vertical a-spacing-none\\\" style=\\\"box-sizing: border-box; margin: 0px; padding: 0px;\\\"\\u003e\\u003cli style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"a-list-item\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003cspan class=\\\"a-text-bold\\\" style=\\\"box-sizing: border-box; font-weight: 700 !important;\\\"\\u003eProduct Dimensions:\\u0026nbsp;\\u003c/span\\u003e\\u003cspan style=\\\"box-sizing: border-box;\\\"\\u003e5 x 5 x 0.7 inches\\u003c/span\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003cli style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"a-list-item\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003cspan class=\\\"a-text-bold\\\" style=\\\"box-sizing: border-box; font-weight: 700 !important;\\\"\\u003eShipping Weight:\\u0026nbsp;\\u003c/span\\u003e\\u003cspan style=\\\"box-sizing: border-box;\\\"\\u003e12 ounces (\\u003ca href=\\\"https://www.amazon.com/gp/help/seller/shipping.html/ref=dp_pd_shipping?_encoding=UTF8\\u0026amp;seller=\\u0026amp;asin=B078J5W5Z2\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eView shipping rates and policies\\u003c/a\\u003e)\\u003c/span\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003cli style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"a-list-item\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003cspan class=\\\"a-text-bold\\\" style=\\\"box-sizing: border-box; font-weight: 700 !important;\\\"\\u003eASIN:\\u0026nbsp;\\u003c/span\\u003e\\u003cspan style=\\\"box-sizing: border-box;\\\"\\u003eB078J5W5Z2\\u003c/span\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003cli style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"a-list-item\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003cli style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"a-list-item\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003cspan class=\\\"a-text-bold\\\" style=\\\"box-sizing: border-box; font-weight: 700 !important;\\\"\\u003eItem model number:\\u0026nbsp;\\u003c/span\\u003e\\u003cspan style=\\\"box-sizing: border-box;\\\"\\u003eCONV-M9622\\u003c/span\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003cli style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"a-list-item\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003cspan class=\\\"a-text-bold\\\" style=\\\"box-sizing: border-box; font-weight: 700 !important;\\\"\\u003eDate first listed on Amazon:\\u0026nbsp;\\u003c/span\\u003e\\u003cspan style=\\\"box-sizing: border-box;\\\"\\u003eSeptember 4, 2003\\u003c/span\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003cli style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"a-list-item\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003cli style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"a-list-item\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003cspan class=\\\"a-text-bold\\\" style=\\\"box-sizing: border-box; font-weight: 700 !important;\\\"\\u003eDomestic Shipping:\\u0026nbsp;\\u003c/span\\u003e\\u003cspan style=\\\"box-sizing: border-box;\\\"\\u003eCurrently, item can be shipped only within the U.S. and to APO/FPO addresses. For APO/FPO shipments, please check with the manufacturer regarding warranty and support issues.\\u003c/span\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003cli style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"a-list-item\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003cspan class=\\\"a-text-bold\\\" style=\\\"box-sizing: border-box; font-weight: 700 !important;\\\"\\u003eInternational Shipping:\\u0026nbsp;\\u003c/span\\u003e\\u003cspan style=\\\"box-sizing: border-box;\\\"\\u003eThis item is not eligible for international shipping.\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/help/customer/display.html?ie=UTF8\\u0026amp;nodeId=201117930\\\" target=\\\"InternationalShippingDetails\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eLearn More\\u003c/a\\u003e\\u003c/span\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003c/ul\\u003e\\u003c/div\\u003e\\u003cdiv id=\\\"dpx-amazon-sales-rank_feature_div\\\" style=\\\"box-sizing: border-box;\\\"\\u003e\\u003cli id=\\\"SalesRank\\\" style=\\\"box-sizing: border-box; list-style: none;\\\"\\u003e\\u003cspan style=\\\"box-sizing: border-box; font-weight: 700;\\\"\\u003eAmazon Best Sellers Rank:\\u003c/span\\u003e\\u0026nbsp;#453 in Clothing, Shoes \\u0026amp; Jewelry (\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/ref=pd_dp_ts_fashion_1\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eSee Top 100 in Clothing, Shoes \\u0026amp; Jewelry\\u003c/a\\u003e)\\u003cul class=\\\"zg_hrsr\\\" style=\\\"box-sizing: border-box; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 5px !important; color: inherit; padding: 0px; list-style-type: none;\\\"\\u003e\\u003cli class=\\\"zg_hrsr_item\\\" style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"zg_hrsr_rank\\\" style=\\\"box-sizing: border-box; display: inline-block; width: auto; text-align: right;\\\"\\u003e#1\\u003c/span\\u003e\\u0026nbsp;\\u003cspan class=\\\"zg_hrsr_ladder\\\" style=\\\"box-sizing: border-box;\\\"\\u003ein\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/ref=pd_zg_hrsr_fashion_1_1\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eClothing, Shoes \\u0026amp; Jewelry\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/7147441011/ref=pd_zg_hrsr_fashion_1_2\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eMen\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/679255011/ref=pd_zg_hrsr_fashion_1_3\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eShoes\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/6127770011/ref=pd_zg_hrsr_fashion_1_4\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eAthletic\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/10294506011/ref=pd_zg_hrsr_fashion_1_5\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eTeam Sports\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003cspan style=\\\"box-sizing: border-box; font-weight: 700;\\\"\\u003e\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/679260011/ref=pd_zg_hrsr_fashion_1_6_last\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eMen\'s\\u003c/a\\u003e\\u003c/span\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003cli class=\\\"zg_hrsr_item\\\" style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"zg_hrsr_rank\\\" style=\\\"box-sizing: border-box; display: inline-block; width: auto; text-align: right;\\\"\\u003e#1\\u003c/span\\u003e\\u0026nbsp;\\u003cspan class=\\\"zg_hrsr_ladder\\\" style=\\\"box-sizing: border-box;\\\"\\u003ein\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/ref=pd_zg_hrsr_fashion_2_1\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eClothing, Shoes \\u0026amp; Jewelry\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/7147440011/ref=pd_zg_hrsr_fashion_2_2\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eWomen\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/679337011/ref=pd_zg_hrsr_fashion_2_3\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eShoes\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/6127771011/ref=pd_zg_hrsr_fashion_2_4\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eAthletic\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/10294505011/ref=pd_zg_hrsr_fashion_2_5\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eTeam Sports\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003cspan style=\\\"box-sizing: border-box; font-weight: 700;\\\"\\u003e\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/fashion/679341011/ref=pd_zg_hrsr_fashion_2_6_last\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eWomen\'s\\u003c/a\\u003e\\u003c/span\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003cli class=\\\"zg_hrsr_item\\\" style=\\\"box-sizing: border-box; list-style: none; word-wrap: break-word; margin: 0px;\\\"\\u003e\\u003cspan class=\\\"zg_hrsr_rank\\\" style=\\\"box-sizing: border-box; display: inline-block; width: auto; text-align: right;\\\"\\u003e#1\\u003c/span\\u003e\\u0026nbsp;\\u003cspan class=\\\"zg_hrsr_ladder\\\" style=\\\"box-sizing: border-box;\\\"\\u003ein\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/sporting-goods/ref=pd_zg_hrsr_sporting-goods_3_1\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eSports \\u0026amp; Outdoors\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/sporting-goods/3386071/ref=pd_zg_hrsr_sporting-goods_3_2\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eFan Shop\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/sporting-goods/374747011/ref=pd_zg_hrsr_sporting-goods_3_3\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eFootwear\\u003c/a\\u003e\\u0026nbsp;\\u0026gt;\\u0026nbsp;\\u003cspan style=\\\"box-sizing: border-box; font-weight: 700;\\\"\\u003e\\u003ca href=\\\"https://www.amazon.com/gp/bestsellers/sporting-goods/2309436011/ref=pd_zg_hrsr_sporting-goods_3_4_last\\\" style=\\\"box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192);\\\"\\u003eSneakers\\u003c/a\\u003e\\u003c/span\\u003e\\u003c/span\\u003e\\u003c/li\\u003e\\u003c/ul\\u003e\\u003c/li\\u003e\\u003c/div\\u003e\\u003c/div\\u003e\\u003c/div\\u003e\\u003caudio controls=\\\"controls\\\" style=\\\"display: none;\\\"\\u003e\\u003c/audio\\u003e\"}',20.50,14.30,'793,794,795,796,797,798,799,800',1,26,0,0,1,1,3,0,0,'',100.00,0,0,NULL,'0',0,'','static/goods/15409749857vkv.png','{\"50\":\"static/goods/15409749857vkv.png\"}',NULL,'{\"50\":\"\"}'),(272,'商品图片测试','11','95',NULL,0,NULL,'2018-10-31 05:23:35','off',0.00,0.00,0.00,0.00,'off',123.00,1233.00,123.00,'1',19,1.00,0.00,'static/goodsNews/154097182711111-1 (2).jpg',NULL,0,'111','{\"50\":\"商品图片测试\"}','{\"50\":\"sdsa\"}','{\"50\":\"adsr\"}',1.00,1.00,'',1,26,0,0,1,1,2,0,0,'',123.00,123,123,NULL,'0',1,'','static/goods/15409718272m0e.jpg','{\"50\":\"\"}',NULL,'{\"50\":\"azser\"}');
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_area`
--

DROP TABLE IF EXISTS `goods_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_area` (
  `goods_area_id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `is_del` int(11) DEFAULT '0',
  PRIMARY KEY (`goods_area_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='分区商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_area`
--

LOCK TABLES `goods_area` WRITE;
/*!40000 ALTER TABLE `goods_area` DISABLE KEYS */;
/*!40000 ALTER TABLE `goods_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_attr`
--

DROP TABLE IF EXISTS `goods_attr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_attr` (
  `goods_attr_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_attr_name` varchar(30) DEFAULT NULL COMMENT '属性名称',
  `goods_attr_pid` int(11) NOT NULL DEFAULT '0' COMMENT '商品属性父类id',
  `is_del` tinyint(4) DEFAULT '0',
  `has_specifications` varchar(10) DEFAULT 'off' COMMENT '是否是规格属性',
  `goods_specifications_unit` varchar(30) DEFAULT NULL COMMENT '规格的单位',
  `goods_attr_val` varchar(30) DEFAULT NULL COMMENT '属性值',
  `goods_attr_type` int(11) DEFAULT '0' COMMENT '0:属性集 1:预定义属性 2：预定义规格属性3：自定义文本属性 4：自定义规格属性',
  `pwd` int(11) DEFAULT NULL,
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '自定义属性的商品id',
  `merchant_id` int(11) DEFAULT '0' COMMENT 'saas id',
  `attr_set_id` int(11) NOT NULL DEFAULT '0' COMMENT '属性集id',
  `is_sku` int(11) NOT NULL DEFAULT '0' COMMENT '是否是sku属性',
  `is_color` int(11) NOT NULL DEFAULT '0',
  `write_method` varchar(20) DEFAULT NULL COMMENT '普通属性的录入方式',
  `goods_attr_alias` varchar(100) DEFAULT NULL COMMENT '属性别名',
  PRIMARY KEY (`goods_attr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8 COMMENT='商品属性表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_attr`
--

LOCK TABLES `goods_attr` WRITE;
/*!40000 ALTER TABLE `goods_attr` DISABLE KEYS */;
INSERT INTO `goods_attr` VALUES (92,NULL,0,0,'off',NULL,NULL,0,NULL,0,19,43,1,0,'1','{\"50\":\"size\"}'),(93,NULL,0,0,'off',NULL,NULL,0,NULL,0,19,43,1,1,'1','{\"50\":\"colour\"}');
/*!40000 ALTER TABLE `goods_attr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_attr_set`
--

DROP TABLE IF EXISTS `goods_attr_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_attr_set` (
  `goods_attr_set_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_attr_set_name` varchar(20) NOT NULL COMMENT '属性集名称',
  `is_del` int(11) NOT NULL DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  PRIMARY KEY (`goods_attr_set_id`),
  UNIQUE KEY `goods_attr_set_goods_attr_set_name_uindex` (`goods_attr_set_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='属性集表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_attr_set`
--

LOCK TABLES `goods_attr_set` WRITE;
/*!40000 ALTER TABLE `goods_attr_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `goods_attr_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_attr_val`
--

DROP TABLE IF EXISTS `goods_attr_val`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_attr_val` (
  `goods_attr_val_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_attr_id` int(11) DEFAULT NULL,
  `goods_attr_val` varchar(30) DEFAULT NULL,
  `is_del` tinyint(4) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `is_open` tinyint(4) DEFAULT '0' COMMENT '列表选项是否选中',
  `goods_attr_val_pid` int(11) DEFAULT '0',
  `language_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`goods_attr_val_id`)
) ENGINE=InnoDB AUTO_INCREMENT=801 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_attr_val`
--

LOCK TABLES `goods_attr_val` WRITE;
/*!40000 ALTER TABLE `goods_attr_val` DISABLE KEYS */;
INSERT INTO `goods_attr_val` VALUES (793,92,'4',0,0,19,0,0,50),(794,92,'5',0,0,19,0,0,50),(795,92,'6',0,0,19,0,0,50),(796,92,'7',0,0,19,0,0,50),(797,93,'pink',0,0,19,0,0,50),(798,93,'blue',0,0,19,0,0,50),(799,93,'red',0,0,19,0,0,50),(800,93,'black',0,0,19,0,0,50);
/*!40000 ALTER TABLE `goods_attr_val` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_category`
--

DROP TABLE IF EXISTS `goods_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_parent_id` int(11) DEFAULT NULL COMMENT '树形结构父id',
  `is_shown_index` varchar(10) DEFAULT 'on' COMMENT '是否在首页显示',
  `is_on` varchar(10) DEFAULT 'on' COMMENT '是否上架',
  `goods_attr_ids` varchar(60) DEFAULT NULL COMMENT '属性id集合--一个类有多个属性',
  `is_del` tinyint(4) NOT NULL DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `category_img` varchar(40) DEFAULT NULL,
  `headline` varchar(60) DEFAULT NULL,
  `key_word` varchar(30) DEFAULT NULL,
  `simple_description` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `attr_set_id` int(11) DEFAULT '0' COMMENT '属性集id',
  `category_name` varchar(20) NOT NULL,
  `category_name_alias` varchar(120) NOT NULL,
  `detail_description` text,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8 COMMENT='产品分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_category`
--

LOCK TABLES `goods_category` WRITE;
/*!40000 ALTER TABLE `goods_category` DISABLE KEYS */;
INSERT INTO `goods_category` VALUES (95,0,'off','off',NULL,0,19,'',NULL,NULL,NULL,NULL,43,'女鞋','{\"50\":\"女鞋\"}',NULL);
/*!40000 ALTER TABLE `goods_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_comments`
--

DROP TABLE IF EXISTS `goods_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_comments` (
  `goods_commets_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comment_main_img` varchar(100) DEFAULT NULL,
  `comment_content` varchar(255) NOT NULL,
  `comment_lev` int(11) NOT NULL DEFAULT '0',
  `is_append` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是追加内容,0不是,1是 默认0',
  `is_del` tinyint(1) DEFAULT '0',
  `is_exist_img` tinyint(1) DEFAULT '0' COMMENT '是否有图片',
  `thumb_up_num` int(11) DEFAULT '0' COMMENT '点赞数',
  `match_description_star` tinyint(1) DEFAULT '0' COMMENT '相符描述的星星数量(0-5)',
  `ship_speed_star` tinyint(1) DEFAULT '0' COMMENT '物流速度的星星数(0-5)',
  `service_attitude_star` tinyint(1) DEFAULT '1' COMMENT '服务态度的星星数',
  `comment_service` varchar(255) DEFAULT NULL,
  `re_comment` varchar(255) DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`goods_commets_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_comments`
--

LOCK TABLES `goods_comments` WRITE;
/*!40000 ALTER TABLE `goods_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `goods_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_img`
--

DROP TABLE IF EXISTS `goods_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_img` (
  `goods_img_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_img_src` varchar(120) DEFAULT NULL,
  `goods_id` int(11) DEFAULT '0',
  `is_del` tinyint(4) DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `queue_id` varchar(15) DEFAULT NULL,
  `img_type` varchar(15) DEFAULT NULL,
  `img_size` int(10) DEFAULT NULL,
  `img_name` varchar(30) DEFAULT NULL,
  `shop_id` int(11) DEFAULT '0',
  PRIMARY KEY (`goods_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=491 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_img`
--

LOCK TABLES `goods_img` WRITE;
/*!40000 ALTER TABLE `goods_img` DISABLE KEYS */;
INSERT INTO `goods_img` VALUES (481,'static/goodsNews/154088750911844949854478-Snipaste_2018-09-29_18-21-23.png',271,1,19,NULL,NULL,NULL,'Snipaste_2018-09-29_18-21-23.p',0),(482,'static/goodsNews/154088750911844949854478-Snipaste_2018-09-29_18-21-36.png',271,1,19,NULL,NULL,NULL,'Snipaste_2018-09-29_18-21-36.p',0),(483,'static/goodsNews/154088750911844949854478-Snipaste_2018-09-29_18-21-46.png',271,1,19,NULL,NULL,NULL,'Snipaste_2018-09-29_18-21-46.p',0),(484,'static/goodsNews/154096341511111-1 (1).jpg',272,1,19,NULL,NULL,NULL,'1 (1).jpg',0),(485,'static/goodsNews/154097182711111-1 (2).jpg',272,0,19,NULL,NULL,NULL,'1 (2).jpg',0),(486,'static/goodsNews/154097182711111-1 (3).jpg',272,0,19,NULL,NULL,NULL,'1 (3).jpg',0),(487,'static/goodsNews/154097498511844949854478-Snipaste_2018-09-29_18-21-23.png',271,0,19,NULL,NULL,NULL,'Snipaste_2018-09-29_18-21-23.p',0),(488,'static/goodsNews/154097498511844949854478-Snipaste_2018-09-29_18-21-36.png',271,0,19,NULL,NULL,NULL,'Snipaste_2018-09-29_18-21-36.p',0),(489,'static/goodsNews/154097498511844949854478-Snipaste_2018-09-29_18-21-46.png',271,0,19,NULL,NULL,NULL,'Snipaste_2018-09-29_18-21-46.p',0),(490,'static/goodsNews/154097498511844949854478-Snipaste_2018-09-29_20-27-59.png',271,0,19,NULL,NULL,NULL,'Snipaste_2018-09-29_20-27-59.p',0);
/*!40000 ALTER TABLE `goods_img` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_label`
--

DROP TABLE IF EXISTS `goods_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_label` (
  `goods_label_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_label_name` varchar(30) DEFAULT NULL COMMENT '标签名',
  `is_del` tinyint(4) NOT NULL DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `goods_id` int(11) NOT NULL DEFAULT '0',
  `shop_id` int(11) DEFAULT '0',
  PRIMARY KEY (`goods_label_id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_label`
--

LOCK TABLES `goods_label` WRITE;
/*!40000 ALTER TABLE `goods_label` DISABLE KEYS */;
/*!40000 ALTER TABLE `goods_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_sale_set`
--

DROP TABLE IF EXISTS `goods_sale_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_sale_set` (
  `goods_sale_set_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_moq` decimal(10,2) DEFAULT '1.00' COMMENT '最小起订量',
  `goods_sale_num` decimal(10,2) DEFAULT '1000.00' COMMENT '产品销量',
  `goods_stock` decimal(10,2) DEFAULT '0.00' COMMENT '产品库存',
  `goods_warning_stock` decimal(10,2) DEFAULT '50.00' COMMENT '警告库存',
  `goods_max_order_num` decimal(10,2) DEFAULT '0.00' COMMENT '一次最大订货量，0：不限制',
  `merchant_id` int(11) DEFAULT '0',
  PRIMARY KEY (`goods_sale_set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_sale_set`
--

LOCK TABLES `goods_sale_set` WRITE;
/*!40000 ALTER TABLE `goods_sale_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `goods_sale_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_sku`
--

DROP TABLE IF EXISTS `goods_sku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_sku` (
  `goods_sku_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_sku_no` varchar(60) DEFAULT NULL,
  `goods_sku_price` decimal(15,2) NOT NULL DEFAULT '0.00',
  `goods_sku_attr_val_ids` varchar(256) DEFAULT NULL COMMENT '组成商品sku的属性规格id值',
  `is_del` tinyint(4) NOT NULL DEFAULT '0',
  `goods_sku_stock_num` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '库存',
  `sku_add_price_num` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'sku 加价',
  `is_add_price` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否加价',
  `goods_sku_weight` decimal(10,2) DEFAULT '0.00' COMMENT 'sku 重量',
  `goods_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`goods_sku_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1090 DEFAULT CHARSET=utf8 COMMENT='商品sku表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_sku`
--

LOCK TABLES `goods_sku` WRITE;
/*!40000 ALTER TABLE `goods_sku` DISABLE KEYS */;
INSERT INTO `goods_sku` VALUES (1058,'',0.00,'793+797',1,0.00,0.00,0,0.00,271),(1059,'',0.00,'793+798',1,0.00,0.00,0,0.00,271),(1060,'',0.00,'793+799',1,0.00,0.00,0,0.00,271),(1061,'',0.00,'793+800',1,0.00,0.00,0,0.00,271),(1062,'',0.00,'794+797',1,0.00,0.00,0,0.00,271),(1063,'',0.00,'794+798',1,0.00,0.00,0,0.00,271),(1064,'',0.00,'794+799',1,0.00,0.00,0,0.00,271),(1065,'',0.00,'794+800',1,0.00,0.00,0,0.00,271),(1066,'',0.00,'795+797',1,0.00,0.00,0,0.00,271),(1067,'',0.00,'795+798',1,0.00,0.00,0,0.00,271),(1068,'',0.00,'795+799',1,0.00,0.00,0,0.00,271),(1069,'',0.00,'795+800',1,0.00,0.00,0,0.00,271),(1070,'',0.00,'796+797',1,0.00,0.00,0,0.00,271),(1071,'',0.00,'796+798',1,0.00,0.00,0,0.00,271),(1072,'',0.00,'796+799',1,0.00,0.00,0,0.00,271),(1073,'',0.00,'796+800',1,0.00,0.00,0,0.00,271),(1074,'',0.00,'793+797',0,-3.00,0.00,0,0.00,271),(1075,'',0.00,'793+798',0,0.00,0.00,0,0.00,271),(1076,'',0.00,'793+799',0,0.00,0.00,0,0.00,271),(1077,'',0.00,'793+800',0,0.00,0.00,0,0.00,271),(1078,'',0.00,'794+797',0,0.00,0.00,0,0.00,271),(1079,'',0.00,'794+798',0,-2.00,0.00,0,0.00,271),(1080,'',0.00,'794+799',0,0.00,0.00,0,0.00,271),(1081,'',0.00,'794+800',0,0.00,0.00,0,0.00,271),(1082,'',0.00,'795+797',0,0.00,0.00,0,0.00,271),(1083,'',0.00,'795+798',0,0.00,0.00,0,0.00,271),(1084,'',0.00,'795+799',0,0.00,0.00,0,0.00,271),(1085,'',0.00,'795+800',0,0.00,0.00,0,0.00,271),(1086,'',0.00,'796+797',0,0.00,0.00,0,0.00,271),(1087,'',0.00,'796+798',0,0.00,0.00,0,0.00,271),(1088,'',0.00,'796+799',0,0.00,0.00,0,0.00,271),(1089,'',0.00,'796+800',0,-1.00,0.00,0,0.00,271);
/*!40000 ALTER TABLE `goods_sku` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_sku_attr_val_img`
--

DROP TABLE IF EXISTS `goods_sku_attr_val_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_sku_attr_val_img` (
  `goods_sku_attr_val_img_id` int(11) NOT NULL AUTO_INCREMENT,
  `attr_val_img_src` varchar(256) DEFAULT NULL,
  `goods_sku_id` int(11) NOT NULL DEFAULT '0',
  `goods_attr_val_id` int(11) NOT NULL DEFAULT '0',
  `is_del` tinyint(4) NOT NULL DEFAULT '0',
  `goods_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`goods_sku_attr_val_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COMMENT='商品sku选项值配图表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_sku_attr_val_img`
--

LOCK TABLES `goods_sku_attr_val_img` WRITE;
/*!40000 ALTER TABLE `goods_sku_attr_val_img` DISABLE KEYS */;
INSERT INTO `goods_sku_attr_val_img` VALUES (49,'static/goodsSku/154088750911844949854478-Snipaste_2018-09-29_20-27-59.png',0,797,1,271),(50,'static/goodsSku/154088750911844949854478-Snipaste_2018-09-29_18-21-36.png',0,798,1,271),(51,'static/goodsSku/154088750911844949854478-Snipaste_2018-09-29_18-21-46.png',0,799,1,271),(52,'static/goodsSku/154088750911844949854478-Snipaste_2018-09-29_18-21-23.png',0,800,1,271),(53,'static/goodsSku/154097498511844949854478-Snipaste_2018-09-29_20-27-59.png',0,797,0,271),(54,'static/goodsSku/154097498511844949854478-Snipaste_2018-09-29_18-21-36.png',0,798,0,271),(55,'static/goodsSku/154097498511844949854478-Snipaste_2018-09-29_18-21-46.png',0,799,0,271),(56,'static/goodsSku/154097498511844949854478-Snipaste_2018-09-29_18-21-23.png',0,800,0,271);
/*!40000 ALTER TABLE `goods_sku_attr_val_img` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_specifications`
--

DROP TABLE IF EXISTS `goods_specifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_specifications` (
  `goods_specifications_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_specifications_name` varchar(30) NOT NULL,
  `goods_attr_id` int(11) NOT NULL DEFAULT '0' COMMENT '属性id',
  `is_del` tinyint(4) DEFAULT '0',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_time` timestamp NULL DEFAULT NULL,
  `merchant_id` int(11) DEFAULT '0',
  PRIMARY KEY (`goods_specifications_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='商品规格值';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_specifications`
--

LOCK TABLES `goods_specifications` WRITE;
/*!40000 ALTER TABLE `goods_specifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `goods_specifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_buy_goods_info`
--

DROP TABLE IF EXISTS `group_buy_goods_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_buy_goods_info` (
  `group_buy_goods_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `new_price` decimal(10,2) DEFAULT NULL,
  `goods_price` decimal(10,2) DEFAULT '0.00',
  `groupNum` int(11) DEFAULT NULL,
  `limitNum` int(11) DEFAULT NULL,
  `pintuan_type` int(11) NOT NULL DEFAULT '3',
  `overTime` tinyint(1) DEFAULT '0',
  `begin_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `merchant_id` int(11) DEFAULT '0',
  `is_del` int(11) NOT NULL DEFAULT '0',
  `marketing_status` tinyint(1) NOT NULL DEFAULT '1',
  `goods_name` varchar(30) DEFAULT '0',
  `default_order_num` int(11) DEFAULT NULL,
  `default_group_num` int(11) NOT NULL DEFAULT '0',
  `goods_stock_num` int(11) NOT NULL DEFAULT '0' COMMENT '库存',
  `is_auto` tinyint(4) DEFAULT '0' COMMENT '是否自动成团',
  PRIMARY KEY (`group_buy_goods_info_id`,`marketing_status`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_buy_goods_info`
--

LOCK TABLES `group_buy_goods_info` WRITE;
/*!40000 ALTER TABLE `group_buy_goods_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_buy_goods_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_buy_task`
--

DROP TABLE IF EXISTS `group_buy_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_buy_task` (
  `group_buy_task_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '拼团ID',
  `goods_info_id` int(11) NOT NULL COMMENT '团购商品ID',
  `create_user_id` int(11) NOT NULL COMMENT '团长ID',
  `is_del` int(11) DEFAULT '0',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_success` smallint(11) DEFAULT '0' COMMENT '是否拼团成功,1表示成功,其他则还未拼团成功',
  `groupbuy_type` smallint(11) DEFAULT '3' COMMENT '拼团的类型 几人拼团,默认是3人拼团',
  `group_user_num` int(11) NOT NULL DEFAULT '0' COMMENT '团购人数',
  PRIMARY KEY (`group_buy_task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='团购开团任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_buy_task`
--

LOCK TABLES `group_buy_task` WRITE;
/*!40000 ALTER TABLE `group_buy_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_buy_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_buy_task_detail`
--

DROP TABLE IF EXISTS `group_buy_task_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_buy_task_detail` (
  `task_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_info_id` int(11) NOT NULL DEFAULT '0' COMMENT '对应的团购商品的团购ID',
  `task_id` int(11) NOT NULL COMMENT '团购id,对应groupbuy表中的groupbuy_id',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '对应的商品的id',
  `goods_name` varchar(50) DEFAULT NULL,
  `is_created_user` int(11) NOT NULL DEFAULT '0' COMMENT '是否是拼主/团长,0-不是; 1-是;默认不是拼主',
  `created_user_id` int(11) NOT NULL COMMENT '该团购商品的发起人,即拼团拼主或团长',
  `groupbuy_type` int(11) DEFAULT '3' COMMENT '拼团的类型:就是几人拼团,默认是3人拼团',
  `groupbuy_user_id` int(11) DEFAULT '0' COMMENT '团购商品购买者id',
  `groupbuy_user_name` varchar(30) DEFAULT NULL COMMENT '团购商品购买者名字,允许为空,根据其ID来连表查询即可',
  `is_del` int(11) NOT NULL DEFAULT '0',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `is_paid` tinyint(4) DEFAULT '0' COMMENT '是否已经支付?0:没有;1:已经支付;',
  PRIMARY KEY (`task_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='参团明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_buy_task_detail`
--

LOCK TABLES `group_buy_task_detail` WRITE;
/*!40000 ALTER TABLE `group_buy_task_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_buy_task_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_task_num`
--

DROP TABLE IF EXISTS `group_task_num`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_task_num` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品ID',
  `goods_info_id` int(11) DEFAULT NULL COMMENT '团购\n商品的团购ID',
  `task_id` int(11) DEFAULT NULL COMMENT '某个团的ID',
  `joinGroupNum` int(11) DEFAULT '0' COMMENT '被参团的点击数量',
  `shareNum` int(11) DEFAULT '0' COMMENT '被分享的数量',
  `checkOrderNum` int(11) DEFAULT '0' COMMENT '支付成功页面:查看订单按钮点击量',
  `messengerNum` int(11) DEFAULT '0' COMMENT 'messenger点击数量',
  `whatsAppNum` int(11) DEFAULT '0' COMMENT 'WhatsApp点击量',
  `lineNum` int(11) DEFAULT '0' COMMENT 'line点击量',
  `vkNum` int(11) DEFAULT '0' COMMENT 'VK点击量',
  `linkNum` int(11) DEFAULT '0' COMMENT 'link点击量',
  `is_del` tinyint(2) NOT NULL DEFAULT '0',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_task_num`
--

LOCK TABLES `group_task_num` WRITE;
/*!40000 ALTER TABLE `group_task_num` DISABLE KEYS */;
INSERT INTO `group_task_num` VALUES (2,19,0,0,0,0,2,3,0,0,0,0,0,0,'2018-11-01 01:16:14');
/*!40000 ALTER TABLE `group_task_num` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupbuy`
--

DROP TABLE IF EXISTS `groupbuy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groupbuy` (
  `groupbuy_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '拼团ID',
  `marketing_id` int(11) NOT NULL COMMENT '团购商品ID',
  `create_user_id` int(11) NOT NULL COMMENT '团长ID',
  `is_del` int(11) DEFAULT '0',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_success` smallint(11) DEFAULT '0' COMMENT '是否拼团成功,1表示成功,其他则还未拼团成功',
  `groupbuy_type` smallint(11) DEFAULT '3' COMMENT '拼团的类型:就是几人拼团,默认是3人拼团',
  PRIMARY KEY (`groupbuy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupbuy`
--

LOCK TABLES `groupbuy` WRITE;
/*!40000 ALTER TABLE `groupbuy` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupbuy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language_set`
--

DROP TABLE IF EXISTS `language_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language_set` (
  `language_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_name` varchar(30) DEFAULT NULL,
  `id_default` tinyint(4) DEFAULT '0' COMMENT '是否是默认语言',
  `merchant_id` int(11) NOT NULL DEFAULT '0' COMMENT '商户id\r\n	',
  `language_pid` int(11) DEFAULT '0',
  `short_name` varchar(10) DEFAULT NULL COMMENT '简写',
  `national_flag` varchar(40) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `is_use` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COMMENT='语言设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_set`
--

LOCK TABLES `language_set` WRITE;
/*!40000 ALTER TABLE `language_set` DISABLE KEYS */;
INSERT INTO `language_set` VALUES (50,'英文',0,19,0,'en',NULL,NULL,0);
/*!40000 ALTER TABLE `language_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing`
--

DROP TABLE IF EXISTS `marketing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing` (
  `marketing_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `new_price` decimal(10,2) DEFAULT NULL,
  `goods_price` decimal(10,2) DEFAULT '0.00',
  `groupNum` int(11) DEFAULT NULL,
  `limitNum` int(11) DEFAULT NULL,
  `pintuan_type` int(11) NOT NULL DEFAULT '3',
  `overTime` tinyint(1) DEFAULT '0',
  `begin_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `merchant_id` int(11) DEFAULT '0',
  `is_del` int(11) NOT NULL DEFAULT '0',
  `marketing_status` tinyint(1) NOT NULL DEFAULT '1',
  `goods_name` varchar(30) DEFAULT '0',
  `default_order_num` int(11) DEFAULT NULL,
  `default_group_num` int(11) NOT NULL DEFAULT '0',
  `goods_stock_num` int(11) NOT NULL DEFAULT '0' COMMENT '库存',
  `is_auto` tinyint(4) DEFAULT '0' COMMENT '是否自动成团',
  PRIMARY KEY (`marketing_id`,`marketing_status`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing`
--

LOCK TABLES `marketing` WRITE;
/*!40000 ALTER TABLE `marketing` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_groupbuy`
--

DROP TABLE IF EXISTS `marketing_groupbuy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_groupbuy` (
  `marketing_groupBuy_id` int(11) NOT NULL AUTO_INCREMENT,
  `marketing_id` int(11) NOT NULL DEFAULT '0' COMMENT '对应的团购商品的团购ID',
  `groupbuy_id` int(11) NOT NULL COMMENT '团购id,对应groupbuy表中的groupbuy_id',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '对应的商品的id',
  `goods_name` varchar(50) DEFAULT NULL,
  `is_created_user` int(11) NOT NULL DEFAULT '0' COMMENT '是否是拼主/团长,0-不是; 1-是;默认不是拼主',
  `created_user_id` int(11) NOT NULL COMMENT '该团购商品的发起人,即拼团拼主或团长',
  `groupbuy_type` int(11) DEFAULT '3' COMMENT '拼团的类型:就是几人拼团,默认是3人拼团',
  `groupbuy_user_id` int(11) NOT NULL COMMENT '团购商品购买者id',
  `groupbuy_user_name` varchar(30) DEFAULT NULL COMMENT '团购商品购买者名字,允许为空,根据其ID来连表查询即可',
  `is_del` int(11) NOT NULL DEFAULT '0',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`marketing_groupBuy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8 COMMENT='对应的一个拼团团购商品,可以由多人发起多种拼团方式;';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_groupbuy`
--

LOCK TABLES `marketing_groupbuy` WRITE;
/*!40000 ALTER TABLE `marketing_groupbuy` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_groupbuy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `merchant`
--

DROP TABLE IF EXISTS `merchant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merchant` (
  `merchant_id` int(11) NOT NULL AUTO_INCREMENT,
  `pwd` varchar(100) NOT NULL,
  `cell_number` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `check_code` varchar(15) DEFAULT NULL COMMENT '验证码',
  `is_del` int(11) DEFAULT '0',
  `domain` varchar(100) NOT NULL COMMENT '子域名',
  `pc_template_id` int(11) DEFAULT '0' COMMENT 'pc站模板id',
  `mobile_template_id` int(11) NOT NULL DEFAULT '0' COMMENT '手机端模板id',
  `merchant_name` varchar(100) DEFAULT NULL COMMENT '店铺名称',
  `followed_num` int(11) DEFAULT '0' COMMENT '被关注数量,即粉丝数量',
  `default_language_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`merchant_id`),
  UNIQUE KEY `merchant_domain_uindex` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='租户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchant`
--

LOCK TABLES `merchant` WRITE;
/*!40000 ALTER TABLE `merchant` DISABLE KEYS */;
INSERT INTO `merchant` VALUES (19,'3d3a656156d51ffc0a65b4705817a975','18811453940','tianjiayi@smzdm.com',NULL,0,'https://shop.valueq.com',0,0,NULL,0,50);
/*!40000 ALTER TABLE `merchant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_price` decimal(10,2) DEFAULT '0.00',
  `order_remark` varchar(40) DEFAULT NULL,
  `order_pay_type` varchar(10) DEFAULT NULL,
  `order_status` tinyint(4) DEFAULT '1',
  `order_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_del` tinyint(4) DEFAULT '0',
  `address_id` varchar(100) DEFAULT NULL COMMENT '发货地址',
  `user_id` int(11) DEFAULT '0',
  `order_no` varchar(30) DEFAULT NULL COMMENT '订单号',
  `pay_time` timestamp NULL DEFAULT NULL COMMENT '付款时间',
  `order_freight` decimal(10,2) DEFAULT '0.00' COMMENT '运费',
  `order_total_price` decimal(10,2) DEFAULT '0.00' COMMENT '订单总价',
  `order_weight` decimal(10,2) DEFAULT '0.00' COMMENT '订单总重量',
  `goods_weight` decimal(10,2) DEFAULT '0.00',
  `shipping_way_id` int(11) NOT NULL DEFAULT '0' COMMENT '物流渠道',
  `order_img` varchar(100) DEFAULT NULL COMMENT '订单图片',
  `shop_id` int(11) DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `pay_state` tinyint(1) DEFAULT NULL,
  `payment_id` varchar(80) DEFAULT NULL,
  `waybill_no` varchar(30) DEFAULT NULL,
  `delivery_time` timestamp NULL DEFAULT NULL,
  `order_goods_para` varchar(255) DEFAULT NULL,
  `order_from` tinyint(4) DEFAULT '0' COMMENT '订单来源  0:正常购买,与团购无关;1:开团购买:团购团长;2:加入拼团:团购团员;3:拼团单独购买:团购单买',
  `task_detail_id` smallint(11) NOT NULL DEFAULT '0' COMMENT '如果是团购商品,则可以对应到group_buy_task_detail表中的记录;0:不是团购商品',
  `buyer_email` varchar(30) DEFAULT NULL COMMENT '买家的邮箱,用于发货物通知(理论上不能为空)',
  `partner_id` int(11) DEFAULT NULL COMMENT '合伙人的id(即推荐人的id,理论上不能为空)',
  `complete_time` timestamp NULL DEFAULT NULL,
  `message` varchar(100) DEFAULT NULL,
  `group_buy_status` tinyint(2) DEFAULT '0',
  `group_buy_id` int(11) DEFAULT '0',
  `task_id` int(11) DEFAULT NULL,
  `check_out_currency_id` int(11) NOT NULL COMMENT '结算货币id',
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `orders_order_no_uindex` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=765 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (758,19.20,NULL,NULL,1,'2018-10-31 08:18:44',0,'247',161,'1540973924596171115161',NULL,0.00,19.20,0.00,0.00,0,NULL,0,19,NULL,NULL,NULL,NULL,'793+797',1,0,'',NULL,NULL,NULL,1,43,NULL,32),(759,19.20,NULL,'paypal',2,'2018-10-31 09:01:15',0,'247',161,'1540976475011128615161','2018-10-31 10:10:12',0.00,19.20,0.00,0.00,0,NULL,0,19,3,'PAY-1Y96411367453032ELPMXCWY',NULL,NULL,'794+798',1,0,'',NULL,NULL,NULL,2,43,177,32),(760,19.20,NULL,'paypal',2,'2018-10-31 09:27:37',0,'248',162,'1540978057360942231162','2018-10-31 10:28:04',0.00,19.20,0.00,0.00,0,NULL,0,19,3,'PAY-0UK54571R6744773GLPMXLEI',NULL,NULL,'796+800',2,0,'',NULL,NULL,NULL,2,43,177,32),(761,19.20,NULL,'paypal',20,'2018-10-31 09:31:25',0,'248',162,'1540978285639444562162','2018-10-31 10:31:59',0.00,19.20,0.00,0.00,0,NULL,0,19,3,'PAY-0R752927TV557005GLPMXM5A',NULL,NULL,'793+797',1,0,'',NULL,NULL,NULL,1,43,178,32),(762,19.20,NULL,'paypal',20,'2018-10-31 10:19:30',0,'248',162,'1540981170417572453162','2018-10-31 11:20:11',0.00,19.20,0.00,0.00,0,NULL,0,19,3,'PAY-5FF090494P0596717LPMYDOI',NULL,NULL,'794+798',1,0,'',NULL,NULL,NULL,1,43,179,32),(763,19.20,NULL,'paypal',2,'2018-11-01 00:52:37',0,'248',162,'1541033557545764778162','2018-11-01 01:53:08',0.00,19.20,0.00,0.00,0,NULL,0,19,3,'PAY-8N372350BR516770JLPNE4XI',NULL,NULL,'793+797',1,0,'',NULL,NULL,NULL,2,43,180,32),(764,20.50,NULL,'paypal',2,'2018-11-01 01:15:23',0,'248',162,'154103492316289','2018-11-01 02:15:55',0.00,20.50,0.00,0.00,0,NULL,0,19,3,'PAY-07523882WP905933ELPNFHMQ',NULL,NULL,'793+797',0,0,'912337767@qq.com',NULL,NULL,NULL,0,43,NULL,32);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_goods`
--

DROP TABLE IF EXISTS `orders_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_goods` (
  `order_goods_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `goods_num` int(11) DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_del` tinyint(4) DEFAULT '0',
  `order_goods_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '单笔商品总价',
  `shop_id` int(11) DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `is_review` tinyint(1) NOT NULL DEFAULT '0',
  `goods_sku_id` smallint(11) DEFAULT NULL COMMENT 'goods_sku表中的多规格id;为空就是非多规格商品',
  `goods_img` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`order_goods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=582 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_goods`
--

LOCK TABLES `orders_goods` WRITE;
/*!40000 ALTER TABLE `orders_goods` DISABLE KEYS */;
INSERT INTO `orders_goods` VALUES (575,758,271,1,'2018-10-31 08:18:44',0,19.20,0,0,0,1058,'static/goodsSku/154088750911844949854478-Snipaste_2018-09-29_20-27-59.png'),(576,759,271,1,'2018-10-31 09:01:15',0,19.20,0,0,0,1079,'static/goodsSku/154097498511844949854478-Snipaste_2018-09-29_18-21-36.png'),(577,760,271,1,'2018-10-31 09:27:37',0,19.20,0,0,0,1089,'static/goodsSku/154097498511844949854478-Snipaste_2018-09-29_18-21-23.png'),(578,761,271,1,'2018-10-31 09:31:25',0,19.20,0,0,0,1074,'static/goodsSku/154097498511844949854478-Snipaste_2018-09-29_20-27-59.png'),(579,762,271,1,'2018-10-31 10:19:30',0,19.20,0,0,0,1079,'static/goodsSku/154097498511844949854478-Snipaste_2018-09-29_18-21-36.png'),(580,763,271,1,'2018-11-01 00:52:37',0,19.20,0,0,0,1074,'static/goodsSku/154097498511844949854478-Snipaste_2018-09-29_20-27-59.png'),(581,764,271,1,'2018-11-01 01:15:23',0,20.50,0,19,0,1074,'static/goodsSku/154097498511844949854478-Snipaste_2018-09-29_20-27-59.png');
/*!40000 ALTER TABLE `orders_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_params`
--

DROP TABLE IF EXISTS `payment_params`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_params` (
  `payment_params_id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_name` varchar(180) DEFAULT NULL COMMENT '支付方式名称',
  `payment_type` varchar(20) NOT NULL,
  `logo_src` varchar(40) NOT NULL,
  `service_charge` varchar(10) DEFAULT NULL,
  `clientId` varchar(80) DEFAULT NULL,
  `secret` varchar(200) DEFAULT NULL,
  `is_on` varchar(6) NOT NULL DEFAULT 'on',
  `creditcard_pay` varchar(6) NOT NULL DEFAULT 'off',
  `min_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `max_price` decimal(10,2) DEFAULT NULL,
  `sort_num` int(3) DEFAULT NULL,
  `description` text,
  `merchant_id` int(11) NOT NULL DEFAULT '0',
  `is_online` varchar(6) NOT NULL DEFAULT 'on',
  `is_del` tinyint(1) NOT NULL DEFAULT '0',
  `extra_charge` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`payment_params_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COMMENT='֧??';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_params`
--

LOCK TABLES `payment_params` WRITE;
/*!40000 ALTER TABLE `payment_params` DISABLE KEYS */;
INSERT INTO `payment_params` VALUES (64,'{\"50\":\"paypal\"}','paypal','static/themes/admin2/img/paypal.jpg','0%','ATazwwg5ERYABa8qHMnUjZMp-6CZTGhhXA8YpWnUd3DIx9YLr8Bt5eMCy_ZZfDlyX3opcheWRf1L-XP_','edaf93b076137f1753560bb7b1a1e746be213562b2dafa187fcc459159b0d6943d69851124cedaeeda98f81d8e93236412b18543c16858b8b2fc15cfa605bbe123270970598eeff039b6c1f23925ca29','on','on',0.00,100000.00,0,'{\"50\":\"\"}',19,'on',0,0.00),(65,'{\"50\":\"DHpay\"}','DHpay','static/themes/admin2/img/dhpay.jpeg','0%','paypal','edaf93b076137f1753560bb7b1a1e746be213562b2dafa187fcc459159b0d6943d69851124cedaeeda98f81d8e93236412b18543c16858b8b2fc15cfa605bbe123270970598eeff039b6c1f23925ca29','on','on',0.00,100000.00,0,'{\"50\":\"\"}',19,'on',0,0.00);
/*!40000 ALTER TABLE `payment_params` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_params_record`
--

DROP TABLE IF EXISTS `payment_params_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_params_record` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pay_type` varchar(20) DEFAULT NULL,
  `clientId` varchar(255) DEFAULT NULL,
  `secret` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8 COMMENT='支付参数修改记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_params_record`
--

LOCK TABLES `payment_params_record` WRITE;
/*!40000 ALTER TABLE `payment_params_record` DISABLE KEYS */;
INSERT INTO `payment_params_record` VALUES (105,19,'2018-10-31 09:19:42','paypal','ATazwwg5ERYABa8qHMnUjZMp-6CZTGhhXA8YpWnUd3DIx9YLr8Bt5eMCy_ZZfDlyX3opcheWRf1L-XP_','edaf93b076137f1753560bb7b1a1e746be213562b2dafa187fcc459159b0d6943d69851124cedaeeda98f81d8e93236412b18543c16858b8b2fc15cfa605bbe123270970598eeff039b6c1f23925ca29'),(106,19,'2018-10-31 09:56:30','paypal','ATazwwg5ERYABa8qHMnUjZMp-6CZTGhhXA8YpWnUd3DIx9YLr8Bt5eMCy_ZZfDlyX3opcheWRf1L-XP_','edaf93b076137f1753560bb7b1a1e746be213562b2dafa187fcc459159b0d6943d69851124cedaeeda98f81d8e93236412b18543c16858b8b2fc15cfa605bbe123270970598eeff039b6c1f23925ca29'),(107,19,'2018-10-31 10:08:22','DHpay','paypal','edaf93b076137f1753560bb7b1a1e746be213562b2dafa187fcc459159b0d6943d69851124cedaeeda98f81d8e93236412b18543c16858b8b2fc15cfa605bbe123270970598eeff039b6c1f23925ca29');
/*!40000 ALTER TABLE `payment_params_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printer_setting`
--

DROP TABLE IF EXISTS `printer_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printer_setting` (
  `printer_setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `corp_name` varchar(50) DEFAULT NULL COMMENT '公司名称',
  `corp_fax` varchar(30) DEFAULT NULL COMMENT '公司传真',
  `corp_tel` varchar(20) DEFAULT NULL,
  `corp_email` varchar(50) DEFAULT NULL COMMENT '公司邮箱',
  `corp_address` varchar(100) DEFAULT NULL COMMENT '公司地址',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_del` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `shop_id` int(11) DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  PRIMARY KEY (`printer_setting_id`),
  UNIQUE KEY `printer_setting_user_id_uindex` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='打印参数设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printer_setting`
--

LOCK TABLES `printer_setting` WRITE;
/*!40000 ALTER TABLE `printer_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `printer_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `red_bag`
--

DROP TABLE IF EXISTS `red_bag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `red_bag` (
  `red_bag_id` int(11) NOT NULL AUTO_INCREMENT,
  `red_bag_name` varchar(30) DEFAULT NULL COMMENT '封面名称',
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `red_bag_end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `red_bag_begin_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `red_bag_type` tinyint(4) DEFAULT '0' COMMENT '0：裂变红包 1：普通红包',
  `red_bag_total_money` decimal(10,2) DEFAULT '0.00',
  `red_bag_num` int(11) NOT NULL DEFAULT '0' COMMENT '红包总数量',
  `red_bag_single_money_is_random` tinyint(4) DEFAULT '0' COMMENT '裂变红包中单个红包金额随机或者固定',
  `merchant_id` int(11) NOT NULL DEFAULT '0',
  `red_bag_time` varchar(50) DEFAULT NULL,
  `is_del` int(11) NOT NULL DEFAULT '0',
  `red_bag_receive_num` int(11) DEFAULT '0',
  PRIMARY KEY (`red_bag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='红包配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `red_bag`
--

LOCK TABLES `red_bag` WRITE;
/*!40000 ALTER TABLE `red_bag` DISABLE KEYS */;
/*!40000 ALTER TABLE `red_bag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `register_email`
--

DROP TABLE IF EXISTS `register_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `register_email` (
  `register_email_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(40) DEFAULT NULL,
  `merchant_id` int(11) NOT NULL,
  `is_send` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`register_email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='注册邮件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `register_email`
--

LOCK TABLES `register_email` WRITE;
/*!40000 ALTER TABLE `register_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `register_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(30) NOT NULL,
  `rebate` decimal(3,1) DEFAULT '0.0',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_address`
--

DROP TABLE IF EXISTS `shipping_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_address` (
  `address_id` int(11) NOT NULL AUTO_INCREMENT,
  `address_area_province` varchar(20) DEFAULT NULL,
  `address_area_city` varchar(20) DEFAULT NULL,
  `address_area_county` varchar(20) DEFAULT NULL,
  `address_detail` varchar(40) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_del` tinyint(4) DEFAULT '0',
  `address_user_id` int(11) DEFAULT '0',
  `receiver_name` varchar(30) DEFAULT NULL COMMENT '收货人名字',
  `cell_number` varchar(15) DEFAULT NULL COMMENT '收货人电话',
  `is_default` tinyint(4) DEFAULT '0',
  `address_area_country` varchar(20) DEFAULT 'china',
  `post_code` varchar(30) DEFAULT NULL COMMENT '邮编',
  `country_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `first_name` varchar(30) DEFAULT NULL COMMENT '名',
  `last_name` varchar(30) DEFAULT NULL COMMENT '姓',
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_address`
--

LOCK TABLES `shipping_address` WRITE;
/*!40000 ALTER TABLE `shipping_address` DISABLE KEYS */;
INSERT INTO `shipping_address` VALUES (247,'北京市','海淀区中关村 zol在线',NULL,'','2018-10-31 08:17:32',0,0,'预上线环境admin','13423452348',1,'China','4234123',0,161,19,'预上线环境','admin',NULL),(248,'上海市','陆家嘴区 环球中心大厦 111-000',NULL,'','2018-10-31 09:27:25',0,0,'CDC预上线测试valueq','11111111',1,'China','100000',0,162,19,'CDC预上线测试','valueq',NULL),(249,'Bejing','tianlulantu',NULL,'tianlulantu','2018-11-01 05:40:41',0,0,'jiayitian','18811453940',1,'China','7895864',0,164,19,'jiayi','tian',NULL);
/*!40000 ALTER TABLE `shipping_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_template`
--

DROP TABLE IF EXISTS `shipping_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_template` (
  `temp_id` int(11) NOT NULL AUTO_INCREMENT,
  `temp_name` varchar(50) DEFAULT NULL COMMENT '模板名称',
  `temp_status` varchar(10) NOT NULL DEFAULT 'on',
  `is_del` int(11) NOT NULL DEFAULT '0',
  `express_status` varchar(200) DEFAULT NULL COMMENT '模板对应的快递公司启用状态',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `shipping_way_ids` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`temp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='运费模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_template`
--

LOCK TABLES `shipping_template` WRITE;
/*!40000 ALTER TABLE `shipping_template` DISABLE KEYS */;
INSERT INTO `shipping_template` VALUES (26,'鞋','on',0,NULL,0,19,'37');
/*!40000 ALTER TABLE `shipping_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_template_express`
--

DROP TABLE IF EXISTS `shipping_template_express`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_template_express` (
  `s_t_e_id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `express_id` int(11) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL DEFAULT 'on',
  `is_del` int(11) DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  PRIMARY KEY (`s_t_e_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='模板-物流公司对应表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_template_express`
--

LOCK TABLES `shipping_template_express` WRITE;
/*!40000 ALTER TABLE `shipping_template_express` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipping_template_express` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_way`
--

DROP TABLE IF EXISTS `shipping_way`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_way` (
  `shipping_way_id` int(11) NOT NULL AUTO_INCREMENT,
  `shipping_way_name` varchar(20) DEFAULT NULL COMMENT '物流渠道名称',
  `is_del` tinyint(4) DEFAULT '0',
  `img_src` varchar(50) DEFAULT NULL COMMENT 'logo图',
  `merchant_id` int(11) DEFAULT '0',
  PRIMARY KEY (`shipping_way_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COMMENT='物流渠道';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_way`
--

LOCK TABLES `shipping_way` WRITE;
/*!40000 ALTER TABLE `shipping_way` DISABLE KEYS */;
INSERT INTO `shipping_way` VALUES (37,'UPS',0,'static/img/15408870635lc.png',19);
/*!40000 ALTER TABLE `shipping_way` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping_zone`
--

DROP TABLE IF EXISTS `shipping_zone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipping_zone` (
  `shipping_zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `shipping_zone_name` varchar(20) NOT NULL COMMENT '区域名称',
  `shipping_zone_status` varchar(10) NOT NULL DEFAULT 'on',
  `s_zone_is_del` tinyint(4) NOT NULL DEFAULT '0',
  `shipping_way_id` int(11) NOT NULL DEFAULT '0' COMMENT '对应的物流渠道',
  `is_free` tinyint(4) DEFAULT '0',
  `freight_time` varchar(50) NOT NULL DEFAULT '10' COMMENT '货运时间',
  `weight_config` text COMMENT '重量计费配置结构化数据',
  `free_config` text COMMENT '免邮配置结构化数据',
  `country` text,
  `temp_id` int(11) DEFAULT '0',
  `is_del` int(11) NOT NULL DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `express_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`shipping_zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='物流渠道分区列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_zone`
--

LOCK TABLES `shipping_zone` WRITE;
/*!40000 ALTER TABLE `shipping_zone` DISABLE KEYS */;
INSERT INTO `shipping_zone` VALUES (26,'','on',0,37,0,'10','{\"d_weight\":\"10\",\"d_price\":\"0\",\"a_weight\":\"1\",\"a_price\":\"2\",\"r_time\":\"72H\"}','{\"low_price\":\"10\",\"f_time\":\"\"}','China,Hong Kong,Taiwan,Macao,United Arab Emirates,Afghanistan,Armenia,Azerbaijan,Bangladesh,Bahrain,Brunei,Bhutan,Cyprus,Georgia,Guam,Indonesia,Israel,India,British Indian Ocean Territory,Iraq,Iran,Jordan,Japan,Kyrgyzstan,Cambodia,North Korea,South Korea,Kuwait,Kazakhstan,Laos,Lebanon,Sri Lanka,Libya,Myanmar (Burma),Mongolia,Maldives,Malaysia,Nepal,Oman,The Philippines,Pakistan,Palestinian territories,Qatar,Saudi Arabia,Singapore,Syria,Turks & Caicos Islands,Thailand,Tajikistan,Timor-Leste (East Timor),Turkmenistan,Turkey,Uzbekistan,Vietnam,Yemen,Andorra,Albania,Austria,Aland Island,Bosnia & Herzegovina,Belgium,Bulgaria,Belarus,Switzerland,Czech Republic,Germany,Denmark,Estonia,Spain,Finland,Faroe Islands,France,Great Britain (United Kingdom; England),Gibraltar,Greenland,Greece,Croatia,Hungary,Ireland,Isle of Man,Iceland,Italy,Jersey,Jamaica,Liechtenstein,Lithuania,Luxembourg,Latvia,Monaco,Moldova,Montenegro,Republic of Macedonia (FYROM),Malta,Netherlands,Norway,Poland,Portugal,Romania,Serbia,Russian Federation,Sweden,Slovenia,Svalbard and Jan Mayen,Slovakia,San Marino,Sint Maarten,Ukraine,Vatican City (The Holy See)',26,0,19,NULL,NULL);
/*!40000 ALTER TABLE `shipping_zone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_car`
--

DROP TABLE IF EXISTS `shopping_car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopping_car` (
  `car_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `is_del` int(11) DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  PRIMARY KEY (`car_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='购物车主表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_car`
--

LOCK TABLES `shopping_car` WRITE;
/*!40000 ALTER TABLE `shopping_car` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopping_car` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shopping_car_detail`
--

DROP TABLE IF EXISTS `shopping_car_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shopping_car_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car_id` int(11) DEFAULT '0' COMMENT '购物车主表id',
  `goods_id` int(11) NOT NULL DEFAULT '0',
  `quantity` int(11) DEFAULT '0' COMMENT '商品数量',
  `goods_price` decimal(10,2) DEFAULT '0.00',
  `is_del` int(11) DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `merchant_id` int(11) DEFAULT '0',
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shopping_car_detail_goods_id_user_id_uindex` (`goods_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2481 DEFAULT CHARSET=utf8 COMMENT='购物车明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shopping_car_detail`
--

LOCK TABLES `shopping_car_detail` WRITE;
/*!40000 ALTER TABLE `shopping_car_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopping_car_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statistics_num`
--

DROP TABLE IF EXISTS `statistics_num`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statistics_num` (
  `statistics_id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) DEFAULT NULL COMMENT '商户ID',
  `goods_id` int(11) DEFAULT NULL COMMENT '该团购对应的商品',
  `goods_info_id` int(11) DEFAULT NULL COMMENT '拼团商品的团购ID',
  `shareButtonNum` int(11) DEFAULT '0' COMMENT '分享按钮点击量',
  `buyAloneNum` int(11) DEFAULT '0' COMMENT '单独购买按钮点击数量',
  `startGroupNum` int(11) DEFAULT '0' COMMENT '开团按钮点击数量',
  `is_del` tinyint(2) DEFAULT '0',
  `rulesNum` int(11) DEFAULT '0' COMMENT '商品详情页:规则点击数',
  `messengerNum` int(11) DEFAULT '0' COMMENT 'messenger点击数量',
  `whatsAppNum` int(11) DEFAULT '0' COMMENT 'WhatsApp点击量',
  `lineNum` int(11) DEFAULT '0' COMMENT 'line点击量',
  `vkNum` int(11) DEFAULT '0' COMMENT 'VK点击量',
  `linkNum` int(11) DEFAULT '0' COMMENT 'link点击量',
  `specConfirmNum` int(11) DEFAULT '0' COMMENT '规格选择弹窗Confirm点击量',
  `placeOrderNum` int(11) DEFAULT '0' COMMENT '订单确认页面的place order按钮',
  `payNum` int(11) DEFAULT '0' COMMENT '支付页面pay按钮的点击量',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`statistics_id`)
) ENGINE=MyISAM AUTO_INCREMENT=125 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistics_num`
--

LOCK TABLES `statistics_num` WRITE;
/*!40000 ALTER TABLE `statistics_num` DISABLE KEYS */;
INSERT INTO `statistics_num` VALUES (118,19,271,43,1,5,28,0,0,0,0,0,0,0,29,7,0,'2018-11-01 07:11:38'),(119,19,0,NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,'2018-10-31 02:09:44'),(120,19,0,NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,'2018-10-31 02:27:43'),(121,19,0,NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,'2018-10-31 02:31:29'),(122,19,0,NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,'2018-10-31 03:19:34'),(123,19,0,NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,'2018-10-31 17:52:42'),(124,19,0,NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,'2018-10-31 18:15:28');
/*!40000 ALTER TABLE `statistics_num` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_params`
--

DROP TABLE IF EXISTS `system_params`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_params` (
  `system_params_id` int(11) NOT NULL AUTO_INCREMENT,
  `params_name` varchar(50) DEFAULT NULL,
  `merchant_id` int(11) DEFAULT '0',
  `params_value` longtext,
  PRIMARY KEY (`system_params_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COMMENT='ϵͳ????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_params`
--

LOCK TABLES `system_params` WRITE;
/*!40000 ALTER TABLE `system_params` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_params` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) DEFAULT NULL,
  `user_pwd` varchar(50) DEFAULT NULL,
  `cell_number` varchar(13) DEFAULT NULL,
  `is_del` tinyint(4) DEFAULT '0',
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login_time` timestamp NULL DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `consume_num` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '消费总金额',
  `rold_id` int(11) DEFAULT '1',
  `user_age` tinyint(3) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `discount` tinyint(3) DEFAULT '0',
  `upcondition` decimal(10,2) DEFAULT '0.00',
  `role_id` int(11) DEFAULT NULL,
  `merchant_id` int(11) DEFAULT '0',
  `membership_points` int(11) DEFAULT '100' COMMENT '用户积分,初始值100',
  `is_point_alive` int(1) DEFAULT '1' COMMENT '用户积分是否可用,默认为正常--1;被冻结--0',
  `paypal_clientId` varchar(80) DEFAULT NULL,
  `paypal_secret` varchar(80) DEFAULT NULL,
  `linepay_clientId` varchar(80) DEFAULT NULL,
  `linepay_secret` varchar(80) DEFAULT NULL,
  `user_sex` tinyint(1) DEFAULT NULL,
  `user_referrer` int(11) DEFAULT '0',
  `user_remark` varchar(160) DEFAULT NULL,
  `facebook_id` varchar(15) DEFAULT NULL COMMENT 'facebook用户id',
  `wishlist` int(11) DEFAULT NULL COMMENT '收藏夹',
  `attention` int(11) DEFAULT NULL COMMENT '关注',
  `footprint` int(11) DEFAULT NULL COMMENT '足迹',
  `user_point` decimal(10,2) DEFAULT '0.00',
  `birthday` date DEFAULT NULL,
  `nickname` varchar(30) DEFAULT NULL,
  `invitedBy_user_id` int(11) DEFAULT NULL COMMENT '用户的邀请人id:即被谁邀请过来的.',
  `business_type` tinyint(2) DEFAULT NULL,
  `user_stateOrProvince` varchar(50) DEFAULT NULL,
  `user_country` varchar(50) DEFAULT NULL,
  `user_photo` varchar(100) DEFAULT NULL,
  `legal_business_name` varchar(30) DEFAULT NULL,
  `legal_business_phone` varchar(20) DEFAULT NULL,
  `marketing_channels` varchar(11) DEFAULT NULL,
  `language_id` int(11) DEFAULT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `user_role_id` int(11) NOT NULL DEFAULT '0',
  `is_virtual` tinyint(1) DEFAULT '0',
  `valueq_u_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (161,'zjzjzjzj',NULL,'',0,'2018-10-31 05:16:59',NULL,'1396892127@qq.com',19.20,1,NULL,NULL,0,0.00,NULL,19,100,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,NULL,'//static.valueq.com:4430/dist/assets/embed/header-img.png',NULL,NULL,NULL,NULL,NULL,0,0,101122),(162,'cdc',NULL,'',0,'2018-10-31 09:23:52',NULL,'912337767@qq.com',97.30,1,NULL,NULL,0,0.00,NULL,19,100,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,NULL,'//static.valueq.com:4430/dist/assets/embed/header-img.png',NULL,NULL,NULL,NULL,NULL,0,0,101126),(163,'223',NULL,NULL,0,'2018-10-31 10:13:43',NULL,NULL,0.00,1,23,NULL,0,0.00,NULL,19,100,1,NULL,NULL,NULL,NULL,1,0,NULL,NULL,NULL,NULL,NULL,0.00,NULL,'222',NULL,0,NULL,NULL,'https://shop.valueq.com/static/attach/15409808238884708352m0e.jpg',NULL,NULL,NULL,NULL,NULL,0,1,NULL),(164,'wuliuqi',NULL,'',0,'2018-11-01 05:39:50',NULL,'tianjy92@126.com',0.00,1,NULL,NULL,0,0.00,NULL,19,100,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL,NULL,NULL,NULL,NULL,'//static.valueq.com:4430/dist/assets/embed/header-img.png',NULL,NULL,NULL,NULL,NULL,0,0,101120);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-01 14:24:40
